package com.exampletest.mobilestudiotest.lua;

import java.util.List;
import java.util.Random;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.ranges.RangesKt;

/* JADX INFO: compiled from: RobloxGlobals.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0015\n\u0000\n\u0002\u0010\u0006\n\u0002\b\u0006\n\u0002\u0010\b\n\u0002\b\b\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u0007H\u0002J \u0010\t\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\u00072\u0006\u0010\u000b\u001a\u00020\u0007H\u0002J(\u0010\f\u001a\u00020\u00072\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u00072\u0006\u0010\u0010\u001a\u00020\u00072\u0006\u0010\u0011\u001a\u00020\u0007H\u0002J\u001e\u0010\u0012\u001a\u00020\u00072\u0006\u0010\u0013\u001a\u00020\u00072\u0006\u0010\u0014\u001a\u00020\u00072\u0006\u0010\u0015\u001a\u00020\u0007R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0016"}, d2 = {"Lcom/exampletest/mobilestudiotest/lua/Noise;", "", "<init>", "()V", "p", "", "fade", "", "t", "lerp", "a", "b", "grad", "h", "", "x", "y", "z", "perlin", "x0", "y0", "z0", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class Noise {
    public static final Noise INSTANCE = new Noise();
    private static final int[] p;

    private Noise() {
    }

    static {
        int[] iArr = new int[512];
        List listShuffled = CollectionsKt.shuffled(RangesKt.until(0, 256), new Random(1337L));
        for (int i = 0; i < 512; i++) {
            iArr[i] = ((Number) listShuffled.get(i & 255)).intValue();
        }
        p = iArr;
    }

    private final double fade(double t) {
        return t * t * t * ((((6.0d * t) - 15.0d) * t) + 10.0d);
    }

    private final double lerp(double t, double a, double b) {
        return ((b - a) * t) + a;
    }

    private final double grad(int h, double x, double y, double z) {
        double v;
        int hh = h & 15;
        double u = hh < 8 ? x : y;
        if (hh < 4) {
            v = y;
        } else {
            v = (hh == 12 || hh == 14) ? x : z;
        }
        return ((hh & 1) == 0 ? u : -u) + ((hh & 2) == 0 ? v : -v);
    }

    public final double perlin(double x0, double y0, double z0) {
        int X = ((int) Math.floor(x0)) & 255;
        int Y = ((int) Math.floor(y0)) & 255;
        int Z = ((int) Math.floor(z0)) & 255;
        double x = x0 - Math.floor(x0);
        double y = y0 - Math.floor(y0);
        double z = z0 - Math.floor(z0);
        double u = fade(x);
        double v = fade(y);
        double w = fade(z);
        int A = p[X] + Y;
        int AA = p[A] + Z;
        int AB = p[A + 1] + Z;
        int B = p[X + 1] + Y;
        int BA = p[B] + Z;
        int BB = p[B + 1] + Z;
        return lerp(w, lerp(v, lerp(u, grad(p[AA], x, y, z), grad(p[BA], x - 1.0d, y, z)), lerp(u, grad(p[AB], x, y - 1.0d, z), grad(p[BB], x - 1.0d, y - 1.0d, z))), lerp(v, lerp(u, grad(p[AA + 1], x, y, z - 1.0d), grad(p[BA + 1], x - 1.0d, y, z - 1.0d)), lerp(u, grad(p[AB + 1], x, y - 1.0d, z - 1.0d), grad(p[BB + 1], x - 1.0d, y - 1.0d, z - 1.0d))));
    }
}
