package com.exampletest.mobilestudiotest.engine;

import androidx.constraintlayout.core.motion.utils.TypedValues;
import com.exampletest.mobilestudiotest.model.CFrame;
import com.exampletest.mobilestudiotest.model.EnumValue;
import com.exampletest.mobilestudiotest.model.Instance;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.comparisons.ComparisonsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: KeyframeAnim.kt */
/* JADX INFO: loaded from: classes7.dex */
@Metadata(d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\"\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u0000 \u001e2\u00020\u0001:\u0002\u001d\u001eB9\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0018\u0010\b\u001a\u0014\u0012\u0004\u0012\u00020\n\u0012\n\u0012\b\u0012\u0004\u0012\u00020\f0\u000b0\t¢\u0006\u0004\b\r\u0010\u000eJ\u0018\u0010\u0019\u001a\u0004\u0018\u00010\u001a2\u0006\u0010\u001b\u001a\u00020\n2\u0006\u0010\u001c\u001a\u00020\u0003R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R \u0010\b\u001a\u0014\u0012\u0004\u0012\u00020\n\u0012\n\u0012\b\u0012\u0004\u0012\u00020\f0\u000b0\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\n0\u00168F¢\u0006\u0006\u001a\u0004\b\u0017\u0010\u0018¨\u0006\u001f"}, d2 = {"Lcom/exampletest/mobilestudiotest/engine/AnimClip;", "", "length", "", "looped", "", "priority", "", "joints", "", "", "", "Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;", "<init>", "(FZILjava/util/Map;)V", "getLength", "()F", "getLooped", "()Z", "getPriority", "()I", "jointNames", "", "getJointNames", "()Ljava/util/Set;", "sample", "Lcom/exampletest/mobilestudiotest/model/CFrame;", "joint", "t", "Key", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class AnimClip {

    /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE = new Companion(null);
    private final Map<String, Key[]> joints;
    private final float length;
    private final boolean looped;
    private final int priority;

    /* JADX INFO: compiled from: KeyframeAnim.kt */
    @Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u000b\u0018\u00002\u00020\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0007¢\u0006\u0004\b\t\u0010\nR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\b\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0010¨\u0006\u0012"}, d2 = {"Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;", "", "t", "", "cf", "Lcom/exampletest/mobilestudiotest/model/CFrame;", "style", "", "dir", "<init>", "(FLcom/exampletest/mobilestudiotest/model/CFrame;II)V", "getT", "()F", "getCf", "()Lcom/exampletest/mobilestudiotest/model/CFrame;", "getStyle", "()I", "getDir", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Key {
        private final CFrame cf;
        private final int dir;
        private final int style;
        private final float t;

        public Key(float t, CFrame cf, int style, int dir) {
            Intrinsics.checkNotNullParameter(cf, "cf");
            this.t = t;
            this.cf = cf;
            this.style = style;
            this.dir = dir;
        }

        public final CFrame getCf() {
            return this.cf;
        }

        public final int getDir() {
            return this.dir;
        }

        public final int getStyle() {
            return this.style;
        }

        public final float getT() {
            return this.t;
        }
    }

    public AnimClip(float length, boolean looped, int priority, Map<String, Key[]> joints) {
        Intrinsics.checkNotNullParameter(joints, "joints");
        this.length = length;
        this.looped = looped;
        this.priority = priority;
        this.joints = joints;
    }

    public final float getLength() {
        return this.length;
    }

    public final boolean getLooped() {
        return this.looped;
    }

    public final int getPriority() {
        return this.priority;
    }

    public final Set<String> getJointNames() {
        return this.joints.keySet();
    }

    public final CFrame sample(String joint, float t) {
        Intrinsics.checkNotNullParameter(joint, "joint");
        Key[] keys = this.joints.get(joint);
        if (keys == null) {
            return null;
        }
        if (keys.length == 1 || t <= keys[0].getT()) {
            return keys[0].getCf();
        }
        Key last = keys[keys.length - 1];
        if (t >= last.getT()) {
            return last.getCf();
        }
        int i = 0;
        while (i < keys.length - 2 && keys[i + 1].getT() <= t) {
            i++;
        }
        Key a = keys[i];
        Key b = keys[i + 1];
        float span = b.getT() - a.getT();
        return span <= 1.0E-5f ? b.getCf() : Quat.INSTANCE.lerp(a.getCf(), b.getCf(), INSTANCE.ease((t - a.getT()) / span, a.getStyle(), a.getDir()));
    }

    /* JADX INFO: compiled from: KeyframeAnim.kt */
    @Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u001e\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\bJ\u0010\u0010\n\u001a\u00020\u00052\u0006\u0010\u000b\u001a\u00020\u0005H\u0002J\u0010\u0010\f\u001a\u0004\u0018\u00010\r2\u0006\u0010\u000e\u001a\u00020\u000f¨\u0006\u0010"}, d2 = {"Lcom/exampletest/mobilestudiotest/engine/AnimClip$Companion;", "", "<init>", "()V", "ease", "", "x", "style", "", "dir0", "bounceOut", "t", TypedValues.TransitionType.S_FROM, "Lcom/exampletest/mobilestudiotest/engine/AnimClip;", "seq", "Lcom/exampletest/mobilestudiotest/model/Instance;", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final float ease(float x, int style, int dir0) {
            if (style == 0) {
                return x;
            }
            if (style == 1) {
                return 0.0f;
            }
            int dir = (style == 5 || dir0 == 2) ? dir0 : 1 - dir0;
            switch (dir) {
                case 0:
                    return ease$inF(style, x);
                case 1:
                    return 1.0f - ease$inF(style, 1.0f - x);
                default:
                    return x < 0.5f ? ease$inF(style, x * 2.0f) / 2.0f : 1.0f - (ease$inF(style, (1.0f - x) * 2.0f) / 2.0f);
            }
        }

        private static final float ease$inF(int $style, float t) {
            switch ($style) {
                case 2:
                    return (t <= 0.0f || t >= 1.0f) ? t : (-((float) Math.pow(2.0d, (t - 1.0f) * 10.0f))) * ((float) Math.sin(((t - 1.075f) * 6.2831855f) / 0.3f));
                case 3:
                default:
                    return t * t * t;
                case 4:
                    return 1.0f - AnimClip.INSTANCE.bounceOut(1.0f - t);
            }
        }

        private final float bounceOut(float t) {
            if (t < 0.36363637f) {
                return 7.5625f * t * t;
            }
            if (t < 0.72727275f) {
                float u = t - 0.54545456f;
                return (7.5625f * u * u) + 0.75f;
            }
            if (t < 0.90909094f) {
                float u2 = t - 0.8181818f;
                return (7.5625f * u2 * u2) + 0.9375f;
            }
            float u3 = t - 0.95454544f;
            return (7.5625f * u3 * u3) + 0.984375f;
        }

        public final AnimClip from(Instance seq) {
            Intrinsics.checkNotNullParameter(seq, "seq");
            if (!Intrinsics.areEqual(seq.getClassName(), "KeyframeSequence")) {
                return null;
            }
            HashMap lists = new HashMap();
            float length = 0.0f;
            Iterator<Instance> it = seq.getChildren().iterator();
            Intrinsics.checkNotNullExpressionValue(it, "iterator(...)");
            while (it.hasNext()) {
                Instance next = it.next();
                Intrinsics.checkNotNullExpressionValue(next, "next(...)");
                Instance kf = next;
                if (Intrinsics.areEqual(kf.getClassName(), "Keyframe")) {
                    Object obj = kf.get("Time");
                    Number number = obj instanceof Number ? (Number) obj : null;
                    float t = number != null ? number.floatValue() : 0.0f;
                    if (t > length) {
                        length = t;
                    }
                    from$walk(lists, t, kf);
                }
            }
            if (lists.isEmpty()) {
                return null;
            }
            HashMap map = lists;
            Map linkedHashMap = new LinkedHashMap(MapsKt.mapCapacity(map.size()));
            for (Object obj2 : map.entrySet()) {
                linkedHashMap.put(((Map.Entry) obj2).getKey(), (Key[]) CollectionsKt.sortedWith((ArrayList) ((Map.Entry) obj2).getValue(), new Comparator() { // from class: com.exampletest.mobilestudiotest.engine.AnimClip$Companion$from$lambda$2$$inlined$sortedBy$1
                    /* JADX WARN: Multi-variable type inference failed */
                    @Override // java.util.Comparator
                    public final int compare(T t2, T t3) {
                        return ComparisonsKt.compareValues(Float.valueOf(((AnimClip.Key) t2).getT()), Float.valueOf(((AnimClip.Key) t3).getT()));
                    }
                }).toArray(new Key[0]));
                lists = lists;
            }
            boolean z = !Intrinsics.areEqual(seq.get("Loop"), (Object) false);
            Object obj3 = seq.get("Priority");
            EnumValue enumValue = obj3 instanceof EnumValue ? (EnumValue) obj3 : null;
            return new AnimClip(length, z, enumValue != null ? enumValue.getValue() : 0, linkedHashMap);
        }

        private static final void from$walk(HashMap<String, ArrayList<Key>> map, float t, Instance p) {
            ArrayList<Key> arrayList;
            Iterator<Instance> it = p.getChildren().iterator();
            Intrinsics.checkNotNullExpressionValue(it, "iterator(...)");
            while (it.hasNext()) {
                Instance next = it.next();
                Intrinsics.checkNotNullExpressionValue(next, "next(...)");
                Instance c = next;
                if (Intrinsics.areEqual(c.getClassName(), "Pose")) {
                    Object obj = c.get("Weight");
                    Number number = obj instanceof Number ? (Number) obj : null;
                    float w = number != null ? number.floatValue() : 1.0f;
                    if (w > 0.0f) {
                        Object obj2 = c.get("CFrame");
                        CFrame cf = obj2 instanceof CFrame ? (CFrame) obj2 : null;
                        if (cf == null) {
                            cf = CFrame.INSTANCE.getIDENTITY();
                        }
                        Object obj3 = c.get("EasingStyle");
                        EnumValue enumValue = obj3 instanceof EnumValue ? (EnumValue) obj3 : null;
                        int st = enumValue != null ? enumValue.getValue() : 0;
                        Object obj4 = c.get("EasingDirection");
                        EnumValue enumValue2 = obj4 instanceof EnumValue ? (EnumValue) obj4 : null;
                        int dr = enumValue2 != null ? enumValue2.getValue() : 0;
                        HashMap<String, ArrayList<Key>> map2 = map;
                        String name = c.getName();
                        ArrayList<Key> arrayList2 = map2.get(name);
                        if (arrayList2 == null) {
                            arrayList = new ArrayList<>();
                            map2.put(name, arrayList);
                        } else {
                            arrayList = arrayList2;
                        }
                        arrayList.add(new Key(t, cf, st, dr));
                    }
                    from$walk(map, t, c);
                }
            }
        }
    }
}
