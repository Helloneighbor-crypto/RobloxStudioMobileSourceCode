package com.exampletest.mobilestudiotest.core;

import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;

/* JADX INFO: compiled from: Studio.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0007\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007¨\u0006\b"}, d2 = {"Lcom/exampletest/mobilestudiotest/core/Tool;", "", "<init>", "(Ljava/lang/String;I)V", "SELECT", "MOVE", "SCALE", "ROTATE", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public enum Tool {
    SELECT,
    MOVE,
    SCALE,
    ROTATE;

    private static final /* synthetic */ EnumEntries $ENTRIES = EnumEntriesKt.enumEntries($VALUES);

    public static EnumEntries<Tool> getEntries() {
        return $ENTRIES;
    }
}
