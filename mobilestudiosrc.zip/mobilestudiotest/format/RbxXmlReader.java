package com.exampletest.mobilestudiotest.format;

import android.util.Base64;
import android.util.Xml;
import com.exampletest.mobilestudiotest.model.CFrame;
import com.exampletest.mobilestudiotest.model.ClassDb;
import com.exampletest.mobilestudiotest.model.Instance;
import com.exampletest.mobilestudiotest.model.SharedStr;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* JADX INFO: compiled from: RbxXmlReader.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0012\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001:\u0001\u0019B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007J\u0010\u0010\b\u001a\u00020\u00072\u0006\u0010\t\u001a\u00020\nH\u0002J\u0012\u0010\u000b\u001a\u0004\u0018\u00010\f2\u0006\u0010\r\u001a\u00020\u000eH\u0002J\u0010\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\fH\u0002J\u0010\u0010\u0012\u001a\u00020\n2\u0006\u0010\u0011\u001a\u00020\fH\u0002J\u001e\u0010\u0013\u001a\u0010\u0012\u0004\u0012\u00020\u0015\u0012\u0006\u0012\u0004\u0018\u00010\u00010\u00142\u0006\u0010\u0011\u001a\u00020\fH\u0002J\u0010\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\nH\u0002¨\u0006\u001a"}, d2 = {"Lcom/exampletest/mobilestudiotest/format/RbxXmlReader;", "", "<init>", "()V", "read", "Lcom/exampletest/mobilestudiotest/format/RbxDocument;", "bytes", "", "decodeB64", "s", "", "parseTree", "Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;", "p", "Lorg/xmlpull/v1/XmlPullParser;", "cframe", "Lcom/exampletest/mobilestudiotest/model/CFrame;", "n", "content", "convert", "Lkotlin/Pair;", "", "parseSpecial", "", "t", "XNode", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class RbxXmlReader {
    public static final RbxXmlReader INSTANCE = new RbxXmlReader();

    /* JADX INFO: compiled from: RbxXmlReader.kt */
    @Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010$\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0007\n\u0000\b\u0002\u0018\u00002\u00020\u0001B#\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0012\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\u0010\u0010\u0016\u001a\u0004\u0018\u00010\u00002\u0006\u0010\u0017\u001a\u00020\u0003J\u000e\u0010\u0018\u001a\u00020\u00032\u0006\u0010\u0017\u001a\u00020\u0003J\u000e\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u0017\u001a\u00020\u0003R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u001d\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR!\u0010\f\u001a\u0012\u0012\u0004\u0012\u00020\u00000\rj\b\u0012\u0004\u0012\u00020\u0000`\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0015\u0010\u0011\u001a\u00060\u0012j\u0002`\u0013¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015¨\u0006\u001b"}, d2 = {"Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;", "", "name", "", "attrs", "", "<init>", "(Ljava/lang/String;Ljava/util/Map;)V", "getName", "()Ljava/lang/String;", "getAttrs", "()Ljava/util/Map;", "children", "Ljava/util/ArrayList;", "Lkotlin/collections/ArrayList;", "getChildren", "()Ljava/util/ArrayList;", "text", "Ljava/lang/StringBuilder;", "Lkotlin/text/StringBuilder;", "getText", "()Ljava/lang/StringBuilder;", "child", "n", "t", "f", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    private static final class XNode {
        private final Map<String, String> attrs;
        private final ArrayList<XNode> children;
        private final String name;
        private final StringBuilder text;

        public XNode(String name, Map<String, String> attrs) {
            Intrinsics.checkNotNullParameter(name, "name");
            Intrinsics.checkNotNullParameter(attrs, "attrs");
            this.name = name;
            this.attrs = attrs;
            this.children = new ArrayList<>();
            this.text = new StringBuilder();
        }

        public final Map<String, String> getAttrs() {
            return this.attrs;
        }

        public final String getName() {
            return this.name;
        }

        public final ArrayList<XNode> getChildren() {
            return this.children;
        }

        public final StringBuilder getText() {
            return this.text;
        }

        public final XNode child(String n) {
            Object next;
            Intrinsics.checkNotNullParameter(n, "n");
            Iterator it = this.children.iterator();
            while (it.hasNext()) {
                next = it.next();
                if (StringsKt.equals(((XNode) next).name, n, true)) {
                    return (XNode) next;
                }
            }
            next = null;
            return (XNode) next;
        }

        public final String t(String n) {
            StringBuilder sb;
            String string;
            String string2;
            Intrinsics.checkNotNullParameter(n, "n");
            XNode xNodeChild = child(n);
            return (xNodeChild == null || (sb = xNodeChild.text) == null || (string = sb.toString()) == null || (string2 = StringsKt.trim((CharSequence) string).toString()) == null) ? "" : string2;
        }

        public final float f(String n) {
            Intrinsics.checkNotNullParameter(n, "n");
            Float floatOrNull = StringsKt.toFloatOrNull(t(n));
            if (floatOrNull != null) {
                return floatOrNull.floatValue();
            }
            return 0.0f;
        }
    }

    private RbxXmlReader() {
    }

    /* JADX WARN: Code duplicated, block: B:47:0x0180  */
    public final RbxDocument read(byte[] bytes) throws XmlPullParserException, RbxFormatException, IOException {
        Object next;
        String str;
        Instance instance;
        Iterable children;
        Intrinsics.checkNotNullParameter(bytes, "bytes");
        XmlPullParser p = Xml.newPullParser();
        p.setFeature("http://xmlpull.org/v1/doc/features.html#process-namespaces", false);
        p.setInput(new ByteArrayInputStream(bytes), null);
        Intrinsics.checkNotNull(p);
        XNode root = parseTree(p);
        if (root == null) {
            throw new RbxFormatException("Empty XML");
        }
        ArrayList warnings = new ArrayList();
        HashMap refs = new HashMap();
        ArrayList pending = new ArrayList();
        HashMap shared = new HashMap();
        ArrayList pendingShared = new ArrayList();
        LinkedHashMap meta = new LinkedHashMap();
        Iterator it = root.getChildren().iterator();
        do {
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
        } while (!Intrinsics.areEqual(((XNode) next).getName(), "SharedStrings"));
        XNode xNode = (XNode) next;
        String str2 = "";
        if (xNode == null || (children = xNode.getChildren()) == null) {
            str = "";
        } else {
            Iterable<XNode> iterable = children;
            for (XNode xNode2 : iterable) {
                HashMap map = shared;
                XmlPullParser p2 = p;
                String str3 = xNode2.getAttrs().get("md5");
                if (str3 == null) {
                    str3 = str2;
                }
                RbxXmlReader rbxXmlReader = INSTANCE;
                String str4 = str2;
                String string = xNode2.getText().toString();
                Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
                map.put(str3, rbxXmlReader.decodeB64(string));
                p = p2;
                iterable = iterable;
                str2 = str4;
            }
            str = str2;
        }
        ArrayList roots = new ArrayList();
        Iterator<XNode> it2 = root.getChildren().iterator();
        Intrinsics.checkNotNullExpressionValue(it2, "iterator(...)");
        while (it2.hasNext()) {
            XNode next2 = it2.next();
            Intrinsics.checkNotNullExpressionValue(next2, "next(...)");
            XNode c = next2;
            String name = c.getName();
            if (Intrinsics.areEqual(name, "Item")) {
                read$build(roots, refs, pending, pendingShared, warnings, c, null);
            } else if (Intrinsics.areEqual(name, "Meta")) {
                LinkedHashMap linkedHashMap = meta;
                String str5 = c.getAttrs().get("name");
                if (str5 == null) {
                    str5 = str;
                }
                linkedHashMap.put(str5, c.getText().toString());
            }
        }
        Iterator it3 = pending.iterator();
        Intrinsics.checkNotNullExpressionValue(it3, "iterator(...)");
        while (it3.hasNext()) {
            Object next3 = it3.next();
            Intrinsics.checkNotNullExpressionValue(next3, "next(...)");
            Triple triple = (Triple) next3;
            Instance i = (Instance) triple.component1();
            String n = (String) triple.component2();
            String r = (String) triple.component3();
            LinkedHashMap<String, Object> props = i.getProps();
            if (Intrinsics.areEqual(r, "null")) {
                instance = null;
            } else if (r.length() == 0) {
                instance = null;
            } else {
                instance = (Instance) refs.get(r);
            }
            props.put(n, instance);
        }
        Iterator it4 = pendingShared.iterator();
        Intrinsics.checkNotNullExpressionValue(it4, "iterator(...)");
        while (it4.hasNext()) {
            Object next4 = it4.next();
            Intrinsics.checkNotNullExpressionValue(next4, "next(...)");
            Triple triple2 = (Triple) next4;
            Instance i2 = (Instance) triple2.component1();
            String n2 = (String) triple2.component2();
            String k = (String) triple2.component3();
            LinkedHashMap<String, Object> props2 = i2.getProps();
            byte[] bArr = (byte[]) shared.get(k);
            if (bArr == null) {
                bArr = new byte[0];
            }
            props2.put(n2, new SharedStr(bArr));
            it4 = it4;
        }
        return new RbxDocument(roots, meta, warnings);
    }

    private static final void read$build(ArrayList<Instance> arrayList, HashMap<String, Instance> map, ArrayList<Triple<Instance, String, String>> arrayList2, ArrayList<Triple<Instance, String, String>> arrayList3, ArrayList<String> arrayList4, XNode node, Instance parent) {
        Iterable children;
        Iterable iterable;
        int i;
        ArrayList<String> arrayList5 = arrayList4;
        String str = node.getAttrs().get("class");
        if (str == null) {
            str = "Folder";
        }
        Instance inst = new Instance(str);
        if (ClassDb.INSTANCE.isServiceName(inst.getClassName()) && parent == null) {
            inst.setService(true);
        }
        String str2 = node.getAttrs().get("referent");
        if (str2 != null) {
            map.put(str2, inst);
        }
        XNode xNodeChild = node.child("Properties");
        if (xNodeChild != null && (children = xNodeChild.getChildren()) != null) {
            Iterable<XNode> iterable2 = children;
            int i2 = 0;
            for (XNode xNode : iterable2) {
                String str3 = xNode.getAttrs().get("name");
                if (str3 == null) {
                    iterable = iterable2;
                    i = i2;
                } else {
                    try {
                        String name = xNode.getName();
                        if (Intrinsics.areEqual(name, "Ref")) {
                            try {
                                String string = xNode.getText().toString();
                                Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
                                try {
                                    arrayList2.add(new Triple<>(inst, str3, StringsKt.trim((CharSequence) string).toString()));
                                    inst.getPropTypes().put(str3, 19);
                                    iterable = iterable2;
                                    i = i2;
                                } catch (Exception e) {
                                    e = e;
                                    iterable = iterable2;
                                    i = i2;
                                    arrayList5.add("Bad value for " + str3 + ": " + e.getMessage());
                                }
                            } catch (Exception e2) {
                                e = e2;
                            }
                        } else {
                            try {
                                if (Intrinsics.areEqual(name, "SharedString")) {
                                    String string2 = xNode.getText().toString();
                                    Intrinsics.checkNotNullExpressionValue(string2, "toString(...)");
                                    try {
                                        arrayList3.add(new Triple<>(inst, str3, StringsKt.trim((CharSequence) string2).toString()));
                                        inst.getPropTypes().put(str3, 28);
                                        iterable = iterable2;
                                        i = i2;
                                    } catch (Exception e3) {
                                        e = e3;
                                        iterable = iterable2;
                                        i = i2;
                                        arrayList5.add("Bad value for " + str3 + ": " + e.getMessage());
                                    }
                                } else {
                                    try {
                                        Pair<Integer, Object> pairConvert = INSTANCE.convert(xNode);
                                        int iIntValue = pairConvert.component1().intValue();
                                        Object objComponent2 = pairConvert.component2();
                                        if (iIntValue == -1) {
                                            iterable = iterable2;
                                            try {
                                                i = i2;
                                                try {
                                                    arrayList5.add("Unknown XML property type " + xNode.getName() + " (" + str3 + ")");
                                                } catch (Exception e4) {
                                                    e = e4;
                                                    arrayList5.add("Bad value for " + str3 + ": " + e.getMessage());
                                                }
                                            } catch (Exception e5) {
                                                e = e5;
                                                i = i2;
                                            }
                                        } else {
                                            iterable = iterable2;
                                            i = i2;
                                            inst.getProps().put(str3, objComponent2);
                                            inst.getPropTypes().put(str3, Integer.valueOf(iIntValue));
                                        }
                                    } catch (Exception e6) {
                                        e = e6;
                                        iterable = iterable2;
                                        i = i2;
                                        arrayList5.add("Bad value for " + str3 + ": " + e.getMessage());
                                        iterable2 = iterable;
                                        i2 = i;
                                    }
                                }
                            } catch (Exception e7) {
                                e = e7;
                                iterable = iterable2;
                                i = i2;
                                arrayList5.add("Bad value for " + str3 + ": " + e.getMessage());
                                iterable2 = iterable;
                                i2 = i;
                            }
                        }
                    } catch (Exception e8) {
                        e = e8;
                    }
                }
                iterable2 = iterable;
                i2 = i;
            }
        }
        if (parent == null) {
            arrayList.add(inst);
        } else {
            inst.attachRaw(parent);
        }
        Iterable children2 = node.getChildren();
        Collection arrayList6 = new ArrayList();
        for (Object obj : children2) {
            Iterable iterable3 = children2;
            if (Intrinsics.areEqual(((XNode) obj).getName(), "Item")) {
                arrayList6.add(obj);
            }
            children2 = iterable3;
        }
        Iterator it = ((List) arrayList6).iterator();
        while (it.hasNext()) {
            read$build(arrayList, map, arrayList2, arrayList3, arrayList5, (XNode) it.next(), inst);
            arrayList2 = arrayList2;
            arrayList3 = arrayList3;
            arrayList5 = arrayList4;
        }
    }

    private final byte[] decodeB64(String s) {
        try {
            byte[] bArrDecode = Base64.decode(new Regex("\\s").replace(s, ""), 0);
            Intrinsics.checkNotNull(bArrDecode);
            return bArrDecode;
        } catch (Exception e) {
            return new byte[0];
        }
    }

    private final XNode parseTree(XmlPullParser p) throws XmlPullParserException, IOException {
        ArrayList stack = new ArrayList();
        XNode root = null;
        int ev = p.getEventType();
        while (ev != 1) {
            switch (ev) {
                case 2:
                    HashMap attrs = new HashMap();
                    int attributeCount = p.getAttributeCount();
                    for (int i = 0; i < attributeCount; i++) {
                        attrs.put(p.getAttributeName(i), p.getAttributeValue(i));
                    }
                    String name = p.getName();
                    Intrinsics.checkNotNullExpressionValue(name, "getName(...)");
                    XNode n = new XNode(name, attrs);
                    if (stack.isEmpty()) {
                        root = n;
                    } else {
                        ((XNode) CollectionsKt.last((List) stack)).getChildren().add(n);
                    }
                    stack.add(n);
                    break;
                case 3:
                    if (!stack.isEmpty()) {
                        stack.remove(stack.size() - 1);
                    }
                    break;
                case 4:
                case 5:
                    if (!stack.isEmpty()) {
                        ((XNode) CollectionsKt.last((List) stack)).getText().append(p.getText());
                    }
                    break;
            }
            ev = p.nextToken();
        }
        return root;
    }

    private final CFrame cframe(XNode n) {
        return new CFrame(n.f("X"), n.f("Y"), n.f("Z"), n.f("R00"), n.f("R01"), n.f("R02"), n.f("R10"), n.f("R11"), n.f("R12"), n.f("R20"), n.f("R21"), n.f("R22"));
    }

    private final String content(XNode n) {
        XNode u = n.child("url");
        if (u == null) {
            String string = n.getText().toString();
            Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
            return StringsKt.trim((CharSequence) string).toString();
        }
        String string2 = u.getText().toString();
        Intrinsics.checkNotNullExpressionValue(string2, "toString(...)");
        return StringsKt.trim((CharSequence) string2).toString();
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:235:0x0722, code lost:
    
        if (r4.equals("Content") != false) goto L236;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00db, code lost:
    
        if (r4.equals("CFrame") == false) goto L277;
     */
    /* JADX WARN: Code restructure failed: missing block: B:307:?, code lost:
    
        return kotlin.TuplesKt.to(16, cframe(r27));
     */
    /* JADX WARN: Code restructure failed: missing block: B:331:?, code lost:
    
        return kotlin.TuplesKt.to(1, content(r27));
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x010d, code lost:
    
        if (r4.equals("CoordinateFrame") != false) goto L34;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x0123, code lost:
    
        if (r4.equals("ContentId") == false) goto L277;
     */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private final kotlin.Pair<java.lang.Integer, java.lang.Object> convert(com.exampletest.mobilestudiotest.format.RbxXmlReader.XNode r27) {
        /*
            Method dump skipped, instruction units count: 2202
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.exampletest.mobilestudiotest.format.RbxXmlReader.convert(com.exampletest.mobilestudiotest.format.RbxXmlReader$XNode):kotlin.Pair");
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:15:0x0035 A[ORIG_RETURN, RETURN] */
    private final float parseSpecial(String t) {
        String upperCase = t.toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        switch (upperCase) {
            case "INF":
                return Float.POSITIVE_INFINITY;
            case "NAN":
                return Float.NaN;
            case "-INF":
                return Float.NEGATIVE_INFINITY;
            default:
                return 0.0f;
        }
    }
}
