package com.exampletest.mobilestudiotest.format;

import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.core.app.NotificationCompat;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import kotlin.Metadata;
import kotlin.UByte;
import kotlin.UShort;
import kotlin.collections.ArraysKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlin.text.Charsets;
import kotlinx.coroutines.scheduling.WorkQueueKt;

/* JADX INFO: compiled from: CsgMesh.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0015\n\u0000\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\u0005\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u000f\bÆ\u0002\u0018\u00002\u00020\u0001:\u0002&'B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0018\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u00072\u0006\u0010\u000b\u001a\u00020\fH\u0002J\u0018\u0010\r\u001a\u00020\u000e2\u0006\u0010\n\u001a\u00020\u00072\u0006\u0010\u000f\u001a\u00020\u000eH\u0002J\u000e\u0010\u0010\u001a\u00020\u000e2\u0006\u0010\n\u001a\u00020\u0007J\u000e\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0007J \u0010\u0014\u001a\n \u0016*\u0004\u0018\u00010\u00150\u00152\u0006\u0010\n\u001a\u00020\u00072\u0006\u0010\u0017\u001a\u00020\fH\u0002J\u0018\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u00052\u0006\u0010\u001b\u001a\u00020\fH\u0002J\u001a\u0010\u001c\u001a\u00020\u00052\u0006\u0010\u001d\u001a\u00020\u00052\b\u0010\u001e\u001a\u0004\u0018\u00010\u0005H\u0002J\u0018\u0010\u001f\u001a\u00020\u00122\u0006\u0010\n\u001a\u00020\u00072\u0006\u0010 \u001a\u00020\fH\u0002J\u0010\u0010!\u001a\u00020\u00122\u0006\u0010\n\u001a\u00020\u0007H\u0002J&\u0010\"\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\u00072\u0006\u0010#\u001a\u00020\f2\u0006\u0010$\u001a\u00020\f2\u0006\u0010%\u001a\u00020\fR\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006("}, d2 = {"Lcom/exampletest/mobilestudiotest/format/CsgMesh;", "", "<init>", "()V", "KEY", "", "MAGIC", "", "xorByte", "", "b", "i", "", "startsWithMagic", "", "scrambled", "isCsgMesh", "decode", "Lcom/exampletest/mobilestudiotest/format/CsgMesh$Decoded;", "raw", "le", "Ljava/nio/ByteBuffer;", "kotlin.jvm.PlatformType", "at", "checkIndices", "", "idx", "nv", "firstLod", "all", "lods", "decodeList", "version", "decodePacked", "decodeDeltaIndices", "start", "size", "count", "CsgException", "Decoded", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class CsgMesh {
    public static final CsgMesh INSTANCE = new CsgMesh();
    private static final int[] KEY = {86, 46, 110, 88, 49, 32, 48, 4, 52, 105, 12, 119, 12, 1, 94, 0, 26, 96, 55, 105, 29, 82, 43, 7, 79, 36, 89, TypedValues.TYPE_TARGET, 83, 4, 122};
    private static final byte[] MAGIC;

    /* JADX INFO: compiled from: CsgMesh.kt */
    @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\u0018\u00002\u00060\u0001j\u0002`\u0002B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0004¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"Lcom/exampletest/mobilestudiotest/format/CsgMesh$CsgException;", "Ljava/lang/Exception;", "Lkotlin/Exception;", NotificationCompat.CATEGORY_MESSAGE, "", "<init>", "(Ljava/lang/String;)V", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class CsgException extends Exception {
        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public CsgException(String msg) {
            super(msg);
            Intrinsics.checkNotNullParameter(msg, "msg");
        }
    }

    private CsgMesh() {
    }

    /* JADX INFO: compiled from: CsgMesh.kt */
    @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0014\n\u0002\b\u0002\n\u0002\u0010\u0015\n\u0002\b\n\n\u0002\u0010\b\n\u0002\b\u0003\u0018\u00002\u00020\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\b\u0010\tR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\u000bR\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0007\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000eR\u0011\u0010\u0010\u001a\u00020\u00118F¢\u0006\u0006\u001a\u0004\b\u0012\u0010\u0013¨\u0006\u0014"}, d2 = {"Lcom/exampletest/mobilestudiotest/format/CsgMesh$Decoded;", "", "pos", "", "nrm", "colors", "", "indices", "<init>", "([F[F[I[I)V", "getPos", "()[F", "getNrm", "getColors", "()[I", "getIndices", "vertexCount", "", "getVertexCount", "()I", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Decoded {
        private final int[] colors;
        private final int[] indices;
        private final float[] nrm;
        private final float[] pos;

        public Decoded(float[] pos, float[] nrm, int[] colors, int[] indices) {
            Intrinsics.checkNotNullParameter(pos, "pos");
            Intrinsics.checkNotNullParameter(nrm, "nrm");
            Intrinsics.checkNotNullParameter(colors, "colors");
            Intrinsics.checkNotNullParameter(indices, "indices");
            this.pos = pos;
            this.nrm = nrm;
            this.colors = colors;
            this.indices = indices;
        }

        public final int[] getColors() {
            return this.colors;
        }

        public final int[] getIndices() {
            return this.indices;
        }

        public final float[] getNrm() {
            return this.nrm;
        }

        public final float[] getPos() {
            return this.pos;
        }

        public final int getVertexCount() {
            return this.pos.length / 3;
        }
    }

    static {
        byte[] bytes = "CSGMDL".getBytes(Charsets.ISO_8859_1);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        MAGIC = bytes;
    }

    private final byte xorByte(byte[] b, int i) {
        return (byte) (b[i] ^ KEY[i % KEY.length]);
    }

    private final boolean startsWithMagic(byte[] b, boolean scrambled) {
        if (b.length < 10) {
            return false;
        }
        int length = MAGIC.length;
        for (int i = 0; i < length; i++) {
            if ((scrambled ? xorByte(b, i) : b[i]) != MAGIC[i]) {
                return false;
            }
        }
        return true;
    }

    public final boolean isCsgMesh(byte[] b) {
        Intrinsics.checkNotNullParameter(b, "b");
        return startsWithMagic(b, true) || startsWithMagic(b, false);
    }

    public final Decoded decode(byte[] raw) throws CsgException {
        boolean scrambled;
        byte[] b;
        Intrinsics.checkNotNullParameter(raw, "raw");
        if (startsWithMagic(raw, false)) {
            scrambled = false;
        } else {
            scrambled = true;
            if (!startsWithMagic(raw, true)) {
                throw new CsgException("not a union mesh");
            }
        }
        byte[] header = new byte[10];
        for (int i = 0; i < 10; i++) {
            header[i] = scrambled ? INSTANCE.xorByte(raw, i) : raw[i];
        }
        int version = ByteBuffer.wrap(header, 6, 4).order(ByteOrder.LITTLE_ENDIAN).getInt();
        switch (version) {
            case 2:
            case 3:
            case 4:
                if (scrambled) {
                    int length = raw.length;
                    b = new byte[length];
                    for (int i2 = 0; i2 < length; i2++) {
                        b[i2] = INSTANCE.xorByte(raw, i2);
                    }
                } else {
                    b = raw;
                }
                return decodeList(b, version);
            case 5:
            case 6:
                return decodePacked(raw);
            default:
                throw new CsgException("union mesh version " + version + " isn't supported");
        }
    }

    private final ByteBuffer le(byte[] b, int at) {
        ByteBuffer byteBufferOrder = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN);
        byteBufferOrder.position(at);
        return byteBufferOrder;
    }

    private final void checkIndices(int[] idx, int nv) throws CsgException {
        for (int i : idx) {
            if (i < 0 || i >= nv) {
                throw new CsgException("index out of range");
            }
        }
    }

    private final int[] firstLod(int[] all, int[] lods) {
        if (lods == null || lods.length < 2) {
            return all;
        }
        int a = RangesKt.coerceIn(lods[0], 0, all.length);
        int e = RangesKt.coerceIn(lods[1], a, all.length);
        return e - a < 3 ? all : ArraysKt.copyOfRange(all, a, e - ((e - a) % 3));
    }

    private final Decoded decodeList(byte[] b, int version) throws CsgException {
        ByteBuffer bb = le(b, 42);
        int nv = bb.getInt();
        int stride = bb.getInt();
        if (nv < 0 || stride < 40 || (((long) nv) * ((long) stride)) + 50 > b.length) {
            throw new CsgException("bad vertex data");
        }
        float[] pos = new float[nv * 3];
        float[] nrm = new float[nv * 3];
        int[] col = new int[nv];
        int i = 0;
        while (true) {
            if (i >= nv) {
                break;
            }
            int s = (i * stride) + 50;
            bb.position(s);
            pos[i * 3] = bb.getFloat();
            pos[(i * 3) + 1] = bb.getFloat();
            pos[(i * 3) + 2] = bb.getFloat();
            nrm[i * 3] = bb.getFloat();
            nrm[(i * 3) + 1] = bb.getFloat();
            nrm[(i * 3) + 2] = bb.getFloat();
            int r = b[s + 24] & UByte.MAX_VALUE;
            int g = b[s + 25] & UByte.MAX_VALUE;
            int bl = b[s + 26] & UByte.MAX_VALUE;
            int a = b[s + 27] & UByte.MAX_VALUE;
            col[i] = (a << 24) | (r << 16) | (g << 8) | bl;
            i++;
        }
        int i2 = nv * stride;
        bb.position(i2 + 50);
        if (bb.remaining() < 4) {
            throw new CsgException("missing indices");
        }
        int ni = bb.getInt();
        if (ni < 0 || ((long) ni) * 4 > bb.remaining()) {
            throw new CsgException("bad index count");
        }
        int[] idx = new int[ni];
        for (int i3 = 0; i3 < ni; i3++) {
            idx[i3] = bb.getInt();
        }
        checkIndices(idx, nv);
        int[] lods = null;
        if (version >= 4 && bb.remaining() >= 4) {
            int n = bb.getInt();
            if ((1 <= n && n < 65) && bb.remaining() >= n * 4) {
                int[] iArr = new int[n];
                for (int i4 = 0; i4 < n; i4++) {
                    iArr[i4] = bb.getInt();
                }
                lods = iArr;
            }
        }
        return new Decoded(pos, nrm, col, firstLod(idx, lods));
    }

    private final Decoded decodePacked(byte[] b) throws CsgException {
        ByteBuffer bb = le(b, 10);
        int nv = decodePacked$count(bb, -1);
        if (bb.remaining() < nv * 12) {
            throw new CsgException("bad positions");
        }
        int i = nv * 3;
        float[] pos = new float[i];
        for (int i2 = 0; i2 < i; i2++) {
            pos[i2] = bb.getFloat();
        }
        decodePacked$count(bb, nv);
        int nSize = bb.getInt();
        if (nSize != nv * 6 || bb.remaining() < nSize) {
            throw new CsgException("bad normals");
        }
        int i3 = nv * 3;
        float[] nrm = new float[i3];
        for (int i4 = 0; i4 < i3; i4++) {
            nrm[i4] = ((bb.getShort() & UShort.MAX_VALUE) / 32767.0f) - 1.0f;
        }
        decodePacked$count(bb, nv);
        int[] col = new int[nv];
        for (int i5 = 0; i5 < nv; i5++) {
            int r = bb.get() & UByte.MAX_VALUE;
            int g = bb.get() & UByte.MAX_VALUE;
            int bl = bb.get() & UByte.MAX_VALUE;
            int a = bb.get() & UByte.MAX_VALUE;
            col[i5] = (a << 24) | (r << 16) | (g << 8) | bl;
        }
        decodePacked$count(bb, nv);
        bb.position(bb.position() + nv);
        decodePacked$count(bb, nv);
        bb.position(bb.position() + (nv * 8));
        decodePacked$count(bb, nv);
        int tSize = bb.getInt();
        bb.position(bb.position() + tSize);
        int ni = bb.getInt();
        int iSize = bb.getInt();
        if (ni >= 0 && iSize >= 0 && iSize <= bb.remaining()) {
            int[] idx = decodeDeltaIndices(b, bb.position(), iSize, ni);
            checkIndices(idx, nv);
            bb.position(bb.position() + iSize);
            int[] lods = null;
            if (bb.remaining() >= 4) {
                int n = bb.getInt();
                if ((1 <= n && n < 65) && bb.remaining() >= n * 4) {
                    int[] iArr = new int[n];
                    for (int i6 = 0; i6 < n; i6++) {
                        iArr[i6] = bb.getInt();
                    }
                    lods = iArr;
                }
            }
            return new Decoded(pos, nrm, col, firstLod(idx, lods));
        }
        throw new CsgException("bad index data");
    }

    private static final int decodePacked$count(ByteBuffer bb, int expect) throws CsgException {
        int n = bb.getShort() & UShort.MAX_VALUE;
        if (expect < 0 || n == expect) {
            return n;
        }
        throw new CsgException("inconsistent vertex count");
    }

    public final int[] decodeDeltaIndices(byte[] b, int start, int size, int count) throws CsgException {
        int v;
        Intrinsics.checkNotNullParameter(b, "b");
        int[] out = new int[count];
        int p = start;
        int end = start + size;
        int cur = 0;
        int i = 0;
        while (i < count) {
            if (p >= end) {
                throw new CsgException("index data too short");
            }
            int p2 = p + 1;
            int x = b[p] & 255;
            if (x < 128) {
                v = x >= 64 ? x - 128 : x;
            } else {
                if (p2 + 2 > end) {
                    throw new CsgException("index data too short");
                }
                v = ((x & WorkQueueKt.MASK) << 16) | ((b[p2] & UByte.MAX_VALUE) << 8) | (b[p2 + 1] & UByte.MAX_VALUE);
                p2 += 2;
                if (v >= 4194304) {
                    v -= 8388608;
                }
            }
            cur += v;
            out[i] = cur;
            i++;
            p = p2;
        }
        if (p != end) {
            throw new CsgException("index data has " + (end - p) + " extra bytes");
        }
        return out;
    }
}
