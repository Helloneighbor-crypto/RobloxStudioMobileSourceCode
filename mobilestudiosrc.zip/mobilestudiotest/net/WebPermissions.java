package com.exampletest.mobilestudiotest.net;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.text.StringsKt;

/* JADX INFO: compiled from: WebPermissions.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000H\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010$\n\u0002\b\u0004\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0018\u0010\u0012\u001a\n \u0014*\u0004\u0018\u00010\u00130\u00132\u0006\u0010\u0015\u001a\u00020\u0016H\u0002J\u000e\u0010\u0017\u001a\u00020\t2\u0006\u0010\u0018\u001a\u00020\u0005J\u001d\u0010\u0019\u001a\u0004\u0018\u00010\t2\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0018\u001a\u00020\u0005¢\u0006\u0002\u0010\u001aJ\u001a\u0010\u001b\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\t0\u001c2\u0006\u0010\u0015\u001a\u00020\u0016J\u000e\u0010\u001d\u001a\u00020\n2\u0006\u0010\u0015\u001a\u00020\u0016J\u001e\u0010\u001e\u001a\u00020\t2\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0018\u001a\u00020\u00052\u0006\u0010\u001f\u001a\u00020\u0005R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000RB\u0010\u0006\u001a*\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u0005\u0012\u0012\u0012\u0010\u0012\u0006\u0012\u0004\u0018\u00010\t\u0012\u0004\u0012\u00020\n0\b\u0012\u0004\u0012\u00020\n\u0018\u00010\u0007X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\f\"\u0004\b\r\u0010\u000eR\u001a\u0010\u000f\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00110\u0010X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006 "}, d2 = {"Lcom/exampletest/mobilestudiotest/net/WebPermissions;", "", "<init>", "()V", "PREFS", "", "asker", "Lkotlin/Function3;", "Lkotlin/Function1;", "", "", "getAsker", "()Lkotlin/jvm/functions/Function3;", "setAsker", "(Lkotlin/jvm/functions/Function3;)V", "pending", "Ljava/util/concurrent/ConcurrentHashMap;", "Ljava/util/concurrent/CountDownLatch;", "prefs", "Landroid/content/SharedPreferences;", "kotlin.jvm.PlatformType", "ctx", "Landroid/content/Context;", "isRobloxHost", "host", "decision", "(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/Boolean;", "remembered", "", "forgetAll", "allow", "who", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class WebPermissions {
    private static final String PREFS = "web_permissions";
    private static volatile Function3<? super String, ? super String, ? super Function1<? super Boolean, Unit>, Unit> asker;
    public static final WebPermissions INSTANCE = new WebPermissions();
    private static final ConcurrentHashMap<String, CountDownLatch> pending = new ConcurrentHashMap<>();

    private WebPermissions() {
    }

    public final Function3<String, String, Function1<? super Boolean, Unit>, Unit> getAsker() {
        return asker;
    }

    public final void setAsker(Function3<? super String, ? super String, ? super Function1<? super Boolean, Unit>, Unit> function3) {
        asker = function3;
    }

    private final SharedPreferences prefs(Context ctx) {
        return ctx.getApplicationContext().getSharedPreferences(PREFS, 0);
    }

    public final boolean isRobloxHost(String host) {
        Intrinsics.checkNotNullParameter(host, "host");
        String lowerCase = host.toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        String h = StringsKt.trimEnd(lowerCase, '.');
        Iterable<String> iterableListOf = CollectionsKt.listOf((Object[]) new String[]{"roblox.com", "rbxcdn.com", "robloxlabs.com", "rbx.com", "roblox.cn", "roblox.qq.com", "robloxdev.com"});
        if ((iterableListOf instanceof Collection) && ((Collection) iterableListOf).isEmpty()) {
            return false;
        }
        for (String str : iterableListOf) {
            if (Intrinsics.areEqual(h, str) || StringsKt.endsWith$default(h, new StringBuilder().append(".").append(str).toString(), false, 2, (Object) null)) {
                return true;
            }
        }
        return false;
    }

    public final Boolean decision(Context ctx, String host) {
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(host, "host");
        SharedPreferences p = prefs(ctx);
        if (p.contains(host)) {
            return Boolean.valueOf(p.getBoolean(host, false));
        }
        return null;
    }

    public final Map<String, Boolean> remembered(Context ctx) {
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Map<String, ?> all = prefs(ctx).getAll();
        Intrinsics.checkNotNullExpressionValue(all, "getAll(...)");
        Collection arrayList = new ArrayList();
        for (Map.Entry<String, ?> entry : all.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            Pair pair = null;
            Boolean bool = value instanceof Boolean ? (Boolean) value : null;
            if (bool != null) {
                pair = TuplesKt.to(key, Boolean.valueOf(bool.booleanValue()));
            }
            if (pair != null) {
                arrayList.add(pair);
            }
            all = all;
        }
        return MapsKt.toMap((List) arrayList);
    }

    public final void forgetAll(Context ctx) {
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        prefs(ctx).edit().clear().apply();
    }

    public final boolean allow(final Context ctx, final String host, String who) throws InterruptedException {
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(host, "host");
        Intrinsics.checkNotNullParameter(who, "who");
        if (isRobloxHost(host)) {
            return false;
        }
        Boolean boolDecision = decision(ctx, host);
        if (boolDecision != null) {
            return boolDecision.booleanValue();
        }
        Function3<? super String, ? super String, ? super Function1<? super Boolean, Unit>, Unit> function3 = asker;
        if (function3 == null) {
            return false;
        }
        final Ref.BooleanRef mine = new Ref.BooleanRef();
        ConcurrentHashMap<String, CountDownLatch> concurrentHashMap = pending;
        final Function1 function1 = new Function1() { // from class: com.exampletest.mobilestudiotest.net.WebPermissions$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return WebPermissions.allow$lambda$4(mine, (String) obj);
            }
        };
        CountDownLatch countDownLatchComputeIfAbsent = concurrentHashMap.computeIfAbsent(host, new Function() { // from class: com.exampletest.mobilestudiotest.net.WebPermissions$$ExternalSyntheticLambda1
            @Override // java.util.function.Function
            public final Object apply(Object obj) {
                return WebPermissions.allow$lambda$5(function1, obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(countDownLatchComputeIfAbsent, "computeIfAbsent(...)");
        final CountDownLatch latch = countDownLatchComputeIfAbsent;
        if (mine.element) {
            try {
                function3.invoke(host, who, new Function1() { // from class: com.exampletest.mobilestudiotest.net.WebPermissions$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        return WebPermissions.allow$lambda$6(ctx, host, latch, (Boolean) obj);
                    }
                });
            } catch (Exception e) {
                latch.countDown();
            }
        }
        latch.await(2L, TimeUnit.MINUTES);
        if (mine.element) {
            pending.remove(host);
        }
        return Intrinsics.areEqual((Object) decision(ctx, host), (Object) true);
    }

    static final CountDownLatch allow$lambda$4(Ref.BooleanRef $mine, String it) {
        Intrinsics.checkNotNullParameter(it, "it");
        $mine.element = true;
        return new CountDownLatch(1);
    }

    static final CountDownLatch allow$lambda$5(Function1 $tmp0, Object p0) {
        return (CountDownLatch) $tmp0.invoke(p0);
    }

    static final Unit allow$lambda$6(Context $ctx, String $host, CountDownLatch $latch, Boolean ok) {
        if (ok != null) {
            INSTANCE.prefs($ctx).edit().putBoolean($host, ok.booleanValue()).commit();
        }
        $latch.countDown();
        return Unit.INSTANCE;
    }
}
